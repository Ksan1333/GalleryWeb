import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const app = readFileSync(resolve(projectRoot, "src/App.tsx"), "utf8");
const appCss = readFileSync(resolve(projectRoot, "src/App.css"), "utf8");
const shelvesCss = readFileSync(resolve(projectRoot, "src/components/HomeShelves.css"), "utf8");
const mediaCollection = readFileSync(resolve(projectRoot, "src/components/MediaCollection.tsx"), "utf8");
const viewerCss = readFileSync(resolve(projectRoot, "src/components/MediaViewer.css"), "utf8");
const displaySettings = readFileSync(resolve(projectRoot, "src/components/GalleryDisplaySettings.tsx"), "utf8");

const contracts = [
  [app.includes('href="#main-content"'), "skip link targets the main content"],
  [app.includes('id="main-content"'), "main content landmark has a stable target"],
  [app.includes('aria-current={section === item.id ? "page" : undefined}'), "active navigation exposes aria-current"],
  [app.includes('aria-controls="app-navigation"'), "mobile menu controls the navigation drawer"],
  [app.includes('className="mobile-navigation-backdrop"'), "mobile drawer has a dismiss backdrop"],
  [app.includes('className="home-overview-grid"'), "home uses the workspace overview grid"],
  [app.includes('className="quick-access-grid"'), "home exposes format shortcuts"],
  [appCss.includes("@media (max-width: 900px)"), "drawer breakpoint is present"],
  [appCss.includes("@media (max-width: 680px)"), "small-screen layout breakpoint is present"],
  [shelvesCss.includes(".home-shelf-section:first-child { grid-column: 1 / -1; }"), "home shelves use the bento hierarchy"],
  [!mediaCollection.includes('from "./AdjacentSimilarityGroups"'), "adjacent-similarity section is not mounted"],
  [!mediaCollection.includes('from "./FolderGroupsPanel"'), "virtual folder groups are not mounted in the image browser"],
  [mediaCollection.includes('className="favorite-folders-panel"'), "image browser exposes favorite folders"],
  [mediaCollection.includes('const groupMode: GalleryGroupMode = "none"'), "media galleries do not create date groups"],
  [displaySettings.includes('groupMode: "none"') && !displaySettings.includes("日付グループ"), "date grouping stays disabled in display settings"],
  [mediaCollection.includes('compactFileLayout={compactFileGallery}'), "video and book folders use compact media tiles"],
  [appCss.includes(".compact-file-gallery .root-folder-card"), "video and book root folders use compact rows"],
  [viewerCss.includes("width: calc(100vw - 16px)") && viewerCss.includes("height: calc(100dvh - 16px)"), "viewer scales with the application window"],
];

const failures = contracts.filter(([passed]) => !passed);
for (const [passed, description] of contracts) {
  console.log(`${passed ? "PASS" : "FAIL"} ${description}`);
}
if (failures.length > 0) process.exitCode = 1;
