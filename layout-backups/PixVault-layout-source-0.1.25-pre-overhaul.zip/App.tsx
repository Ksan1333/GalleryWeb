import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { listen } from "@tauri-apps/api/event";
import "./App.css";
import { HomeShelves } from "./components/HomeShelves";
import { Icon, type IconName } from "./components/Icon";
import { OperationTray } from "./components/OperationTray";
import { NotificationCenter } from "./components/NotificationCenter";
import {
  defaultGalleryMediaVisibility,
  galleryMediaVisibilityEvent,
  loadGalleryMediaVisibility,
  normalizeGalleryMediaVisibility,
  type GalleryMediaVisibility,
} from "./services/galleryMediaVisibility";
import { firstRunTutorialOpenEvent } from "./services/tutorial";
import { SelectMenu } from "./components/Ui";
import { useAiOperationBridge } from "./hooks/useAiOperationBridge";
import { useThumbnailCacheOperationBridge } from "./hooks/useThumbnailCacheOperationBridge";
import {
  addLibraryRoot,
  emptyLibrarySummary,
  getLibrarySummary,
  getJsonPreference,
  getPreferences,
  getRuntimeInfo,
  invalidateMediaCatalogCache,
  listLibraryRoots,
  listMediaItems,
  pickLibraryRoot,
  removeLibraryRoot,
  scanLibrary,
  setJsonPreference,
  takePendingXUrl,
  type LibraryRoot,
  type LibrarySummary,
  type MediaKind,
  type MediaItem,
  type RuntimeInfo,
  type ViewerInfoLayout,
} from "./services/native";
import {
  rememberFolderNavigation,
  setFolderFavorite,
  type FolderActivityRecord,
} from "./services/folderActivity";
import { operationErrorMessage, startOperation } from "./services/operations";
import {
  tagGalleryNavigationEvent,
  type TagGalleryNavigationRequest,
} from "./services/galleryNavigation";
import {
  openAiAnalysisPanelEvent,
  type AiAnalysisPanelRequest,
} from "./services/aiPanel";
import { releaseNotes } from "./releaseNotes";
import { applyThemePreferences } from "./services/theme";
import { configureNativeNotifications, notifyApp } from "./services/notifications";

const MediaViewer = lazy(() => import("./components/MediaViewer").then((module) => ({ default: module.MediaViewer })));
const AiAnalysisMonitor = lazy(() => import("./components/AiAnalysisMonitor").then((module) => ({ default: module.AiAnalysisMonitor })));
const FirstRunTutorial = lazy(() => import("./components/FirstRunTutorial").then((module) => ({ default: module.FirstRunTutorial })));
const MediaCollection = lazy(() => import("./components/MediaCollection").then((module) => ({ default: module.MediaCollection })));
const FolderMediaCollection = lazy(() => import("./components/MediaCollection").then((module) => ({ default: module.FolderMediaCollection })));
const AIAnalysisModal = lazy(() => import("./components/AIAnalysisModal").then((module) => ({ default: module.AIAnalysisModal })));
const FavoriteSitesPage = lazy(() => import("./components/ExtraPages").then((module) => ({ default: module.FavoriteSitesPage })));
const FavoriteCreatorsPage = lazy(() => import("./components/ExtraPages").then((module) => ({ default: module.FavoriteCreatorsPage })));
const DrawingReferencesPage = lazy(() => import("./components/ExtraPages").then((module) => ({ default: module.DrawingReferencesPage })));
const XDownloaderPage = lazy(() => import("./components/ExtraPages").then((module) => ({ default: module.XDownloaderPage })));
const BookViewerSettings = lazy(() => import("./components/BookViewerSettings").then((module) => ({ default: module.BookViewerSettings })));
const VideoViewerSettings = lazy(() => import("./components/VideoViewerSettings").then((module) => ({ default: module.VideoViewerSettings })));
const GalleryMediaSettings = lazy(() => import("./components/GalleryMediaSettings").then((module) => ({ default: module.GalleryMediaSettings })));
const GalleryDisplaySettings = lazy(() => import("./components/GalleryDisplaySettings").then((module) => ({ default: module.GalleryDisplaySettings })));
const XDownloadDirectorySetting = lazy(() => import("./components/XDownloadDirectorySetting").then((module) => ({ default: module.XDownloadDirectorySetting })));
const DataPortabilitySettings = lazy(() => import("./components/DataPortabilitySettings").then((module) => ({ default: module.DataPortabilitySettings })));
const SearchAndGroupingSettings = lazy(() => import("./components/SearchAndGroupingSettings").then((module) => ({ default: module.SearchAndGroupingSettings })));
const ViewerControlSettings = lazy(() => import("./components/ViewerControlSettings").then((module) => ({ default: module.ViewerControlSettings })));

type Section = "home" | "gallery" | "folders" | "videos" | "books" | "favorites" | "sites" | "creators" | "references" | "downloads" | "settings" | "about" | "changelog";

type NavigationItem = {
  id: Section;
  label: string;
  icon: IconName;
};

const IMAGE_MEDIA_KINDS: MediaKind[] = ["image", "gif"];
const VIDEO_MEDIA_KINDS: MediaKind[] = ["video"];
const BOOK_MEDIA_KINDS: MediaKind[] = ["pdf", "archive"];

function extractXPostUrl(value: string): string | undefined {
  return value.match(/https:\/\/(?:www\.|mobile\.)?(?:x\.com|twitter\.com)\/[^\s<>]+\/status\/\d+/i)?.[0];
}

const navigationGroups: Array<{ label?: string; items: NavigationItem[] }> = [
  {
    items: [
      { id: "home", label: "ホーム", icon: "home" },
      { id: "gallery", label: "ギャラリー", icon: "gallery" },
      { id: "favorites", label: "お気に入り", icon: "star" },
    ],
  },
  {
    label: "メディア",
    items: [
      { id: "folders", label: "画像", icon: "image" },
      { id: "videos", label: "動画", icon: "video" },
      { id: "books", label: "ブック", icon: "book" },
    ],
  },
  {
    label: "便利機能",
    items: [
      { id: "sites", label: "お気に入りサイト", icon: "external" },
      { id: "creators", label: "お気に入りクリエイター", icon: "sparkles" },
      { id: "references", label: "お絵描き資料", icon: "reference" },
      { id: "downloads", label: "X ダウンローダー", icon: "download" },
    ],
  },
  {
    label: "情報",
    items: [
      { id: "settings", label: "設定", icon: "settings" },
      { id: "about", label: "このアプリについて", icon: "info" },
      { id: "changelog", label: "更新履歴", icon: "clock" },
    ],
  },
];
const navigation = navigationGroups.flatMap((group) => group.items);

function messageFrom(...messages: Array<string | undefined>): string | undefined {
  return messages.find((message) => Boolean(message));
}

function ReleaseHistory() {
  const [openVersions, setOpenVersions] = useState<Set<string>>(
    () => new Set(releaseNotes[0] ? [releaseNotes[0].version] : []),
  );
  const toggle = (version: string) => {
    setOpenVersions((current) => {
      const next = new Set(current);
      if (next.has(version)) next.delete(version);
      else next.add(version);
      return next;
    });
  };

  return (
    <div className="release-history-list">
      {releaseNotes.map((release, index) => {
        const open = openVersions.has(release.version);
        return (
          <article className={open ? "is-open" : ""} key={release.version}>
            <button
              type="button"
              className="release-history-summary"
              aria-expanded={open}
              onClick={() => toggle(release.version)}
            >
              <span>
                <em>{index === 0 ? "最新版" : release.date}</em>
                <strong>バージョン {release.version}</strong>
                <small>{release.title}</small>
              </span>
              <Icon name={open ? "minus" : "chevronRight"} />
            </button>
            {open && (
              <ul>
                {release.changes.map((change) => <li key={change}>{change}</li>)}
              </ul>
            )}
          </article>
        );
      })}
    </div>
  );
}

function App() {
  useAiOperationBridge();
  useThumbnailCacheOperationBridge();
  const [section, setSection] = useState<Section>("home");
  const sectionRef = useRef<Section>("home");
  const sectionBackStack = useRef<Section[]>([]);
  const sectionForwardStack = useRef<Section[]>([]);
  const [runtimeInfo, setRuntimeInfo] = useState<RuntimeInfo>();
  const [roots, setRoots] = useState<LibraryRoot[]>([]);
  const [summary, setSummary] = useState<LibrarySummary>(emptyLibrarySummary);
  const [homeFavoriteMedia, setHomeFavoriteMedia] = useState<MediaItem[]>([]);
  const [homeMediaLoading, setHomeMediaLoading] = useState(true);
  const [homeSelectedMediaId, setHomeSelectedMediaId] = useState<string>();
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [sidebarMinimized, setSidebarMinimized] = useState(false);
  const [nativeAvailable, setNativeAvailable] = useState(false);
  const [error, setError] = useState<string>();
  const [viewerInfoLayout, setViewerInfoLayout] = useState<ViewerInfoLayout>("sidebar");
  const [savingViewerInfoLayout, setSavingViewerInfoLayout] = useState(false);
  const [galleryMediaVisibility, setGalleryMediaVisibility] = useState<GalleryMediaVisibility>(
    defaultGalleryMediaVisibility,
  );
  const [tagGalleryNavigation, setTagGalleryNavigation] =
    useState<TagGalleryNavigationRequest>();
  const [aiAnalysisPanelRequest, setAiAnalysisPanelRequest] =
    useState<(AiAnalysisPanelRequest & { requestId: number })>();
  const [catalogRefreshVersion, setCatalogRefreshVersion] = useState(0);
  const [externalXUrl, setExternalXUrl] = useState<string>();

  useEffect(() => {
    let active = true;
    void getPreferences().then((result) => {
      if (!active) return;
      applyThemePreferences(result.data);
      configureNativeNotifications(result.data.nativeNotifications);
    });
    return () => {
      active = false;
    };
  }, []);
  const activeLabel = navigation.find((item) => item.id === section)?.label ?? "ホーム";
  const galleryMediaKinds = useMemo<MediaKind[]>(() => [
    ...IMAGE_MEDIA_KINDS,
    ...(galleryMediaVisibility.video ? VIDEO_MEDIA_KINDS : []),
    ...(galleryMediaVisibility.book ? BOOK_MEDIA_KINDS : []),
  ], [galleryMediaVisibility.book, galleryMediaVisibility.video]);

  useEffect(() => {
    let active = true;
    void getJsonPreference<boolean>("sidebarMinimized", false).then((result) => {
      if (active) setSidebarMinimized(Boolean(result.data));
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const handleOpenAiAnalysis = (event: Event) => {
      const detail = (event as CustomEvent<AiAnalysisPanelRequest>).detail ?? {};
      setAiAnalysisPanelRequest({ ...detail, requestId: Date.now() });
    };
    window.addEventListener(openAiAnalysisPanelEvent, handleOpenAiAnalysis);
    return () => window.removeEventListener(openAiAnalysisPanelEvent, handleOpenAiAnalysis);
  }, []);

  useEffect(() => {
    let active = true;
    void getJsonPreference<ViewerInfoLayout>("viewerInfoLayout", "sidebar").then((result) => {
      if (!active) return;
      setViewerInfoLayout(result.data === "bottomSheet" ? "bottomSheet" : "sidebar");
      if (result.error) setError(result.error);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const handleViewerLayout = (event: Event) => {
      const detail = (event as CustomEvent<ViewerInfoLayout>).detail;
      if (detail === "sidebar" || detail === "bottomSheet") {
        setViewerInfoLayout(detail);
      }
    };
    window.addEventListener("pixvault:viewer-info-layout", handleViewerLayout);
    return () => window.removeEventListener("pixvault:viewer-info-layout", handleViewerLayout);
  }, []);

  useEffect(() => {
    let active = true;
    void loadGalleryMediaVisibility().then((value) => {
      if (active) setGalleryMediaVisibility(value);
    });
    const handleVisibility = (event: Event) => {
      setGalleryMediaVisibility(
        normalizeGalleryMediaVisibility(
          (event as CustomEvent<Partial<GalleryMediaVisibility>>).detail,
        ),
      );
    };
    window.addEventListener(galleryMediaVisibilityEvent, handleVisibility);
    return () => {
      active = false;
      window.removeEventListener(galleryMediaVisibilityEvent, handleVisibility);
    };
  }, []);

  useEffect(() => {
    const suppressNativeContextMenu = (event: MouseEvent) => {
      event.preventDefault();
    };
    window.addEventListener("contextmenu", suppressNativeContextMenu, true);
    return () => window.removeEventListener("contextmenu", suppressNativeContextMenu, true);
  }, []);

  const changeViewerInfoLayout = useCallback(async (value: string) => {
    const next: ViewerInfoLayout = value === "bottomSheet" ? "bottomSheet" : "sidebar";
    const previous = viewerInfoLayout;
    setViewerInfoLayout(next);
    setSavingViewerInfoLayout(true);
    const result = await setJsonPreference("viewerInfoLayout", next);
    setSavingViewerInfoLayout(false);
    if (!result.data || result.error) {
      setViewerInfoLayout(previous);
      setError(result.error ?? "ビュワーの表示設定を保存できませんでした。");
    }
  }, [viewerInfoLayout]);

  const navigateToSection = useCallback((nextSection: Section) => {
    const currentSection = sectionRef.current;
    if (currentSection === nextSection) return;
    sectionBackStack.current.push(currentSection);
    sectionForwardStack.current = [];
    sectionRef.current = nextSection;
    setSection(nextSection);
  }, []);

  useEffect(() => {
    const handleTagGalleryNavigation = (event: Event) => {
      const detail = (event as CustomEvent<TagGalleryNavigationRequest>).detail;
      if (!detail?.tagId || !detail.tagName) return;
      setTagGalleryNavigation(detail);
      navigateToSection("gallery");
    };
    window.addEventListener(tagGalleryNavigationEvent, handleTagGalleryNavigation);
    return () => window.removeEventListener(
      tagGalleryNavigationEvent,
      handleTagGalleryNavigation,
    );
  }, [navigateToSection]);

  const navigateBack = useCallback(() => {
    const detail = { handled: false };
    const request = new CustomEvent("pixvault:navigate-back", {
      cancelable: true,
      detail,
    });
    window.dispatchEvent(request);

    queueMicrotask(() => {
      if (request.defaultPrevented || detail.handled) return;
      const previousSection = sectionBackStack.current.pop();
      if (!previousSection) return;
      sectionForwardStack.current.push(sectionRef.current);
      sectionRef.current = previousSection;
      setSection(previousSection);
    });
  }, []);

  const navigateForward = useCallback(() => {
    const detail = { handled: false };
    const request = new CustomEvent("pixvault:navigate-forward", {
      cancelable: true,
      detail,
    });
    window.dispatchEvent(request);

    queueMicrotask(() => {
      if (request.defaultPrevented || detail.handled) return;
      const nextSection = sectionForwardStack.current.pop();
      if (!nextSection) return;
      sectionBackStack.current.push(sectionRef.current);
      sectionRef.current = nextSection;
      setSection(nextSection);
    });
  }, []);

  useEffect(() => {
    const handleHistoryMouseButton = (event: MouseEvent) => {
      if (event.button !== 3 && event.button !== 4) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.button === 3) navigateBack();
      else navigateForward();
    };
    window.addEventListener("mouseup", handleHistoryMouseButton, true);
    return () => window.removeEventListener("mouseup", handleHistoryMouseButton, true);
  }, [navigateBack, navigateForward]);

  useEffect(() => {
    const handleBackRequest = () => navigateBack();
    const handleForwardRequest = () => navigateForward();
    const handleHistoryBranch = () => {
      sectionForwardStack.current = [];
    };
    window.addEventListener("pixvault:history-back", handleBackRequest);
    window.addEventListener("pixvault:history-forward", handleForwardRequest);
    window.addEventListener("pixvault:history-branch", handleHistoryBranch);
    return () => {
      window.removeEventListener("pixvault:history-back", handleBackRequest);
      window.removeEventListener("pixvault:history-forward", handleForwardRequest);
      window.removeEventListener("pixvault:history-branch", handleHistoryBranch);
    };
  }, [navigateBack, navigateForward]);

  const refresh = useCallback(async (showOperation = true): Promise<string | undefined> => {
    const operation = showOperation
      ? startOperation({
          label: "ライブラリを更新",
          detail: "フォルダーと件数を確認しています",
          progress: null,
        })
      : undefined;
    setLoading(true);
    try {
      const [runtimeResult, rootResult, summaryResult] = await Promise.all([
        getRuntimeInfo(),
        listLibraryRoots(),
        getLibrarySummary(),
      ]);
      setRuntimeInfo(runtimeResult.data);
      setRoots(rootResult.data);
      setSummary(summaryResult.data);
      setNativeAvailable(runtimeResult.available && rootResult.available && summaryResult.available);
      const refreshError = messageFrom(
        runtimeResult.error,
        rootResult.error,
        summaryResult.error,
      );
      setError(refreshError);
      if (refreshError) operation?.fail(refreshError);
      else operation?.succeed(`${summaryResult.data.totalItems.toLocaleString("ja-JP")}件を確認しました`);
      return refreshError;
    } catch (caught) {
      const refreshError = operationErrorMessage(caught);
      setError(refreshError);
      operation?.fail(refreshError);
      return refreshError;
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshSummary = useCallback(async () => {
    const result = await getLibrarySummary();
    if (result.error) {
      setError(result.error);
      return;
    }
    setSummary(result.data);
    setNativeAvailable((current) => current && result.available);
  }, []);

  useEffect(() => {
    if (!nativeAvailable) return;
    let disposed = false;
    let unlisten: (() => void) | undefined;
    void listen<{ inserted: number; updated: number; missing: number }>("library-watch-updated", (event) => {
      invalidateMediaCatalogCache();
      setCatalogRefreshVersion((current) => current + 1);
      if (event.payload.inserted > 0) {
        notifyApp({
          tone: "success",
          title: "ライブラリを更新しました",
          message: `新しいメディアを${event.payload.inserted.toLocaleString("ja-JP")}件追加しました。`,
        });
      }
      void Promise.all([getLibrarySummary(), listLibraryRoots()]).then(([summaryResult, rootsResult]) => {
        if (disposed) return;
        if (!summaryResult.error) setSummary(summaryResult.data);
        if (!rootsResult.error) setRoots(rootsResult.data);
      });
    }).then((stop) => {
      if (disposed) stop();
      else unlisten = stop;
    }).catch(() => undefined);
    return () => {
      disposed = true;
      unlisten?.();
    };
  }, [nativeAvailable]);

  useEffect(() => {
    if (!nativeAvailable) return;
    let active = true;
    void takePendingXUrl().then((result) => {
      if (!active || !result.data) return;
      setExternalXUrl(result.data);
      setSection("downloads");
    });
    return () => {
      active = false;
    };
  }, [nativeAvailable]);

  useEffect(() => {
    const onDragOver = (event: DragEvent) => {
      if ([...(event.dataTransfer?.types ?? [])].some((type) =>
        type === "text/plain" || type === "text/uri-list")) {
        event.preventDefault();
      }
    };
    const onDrop = (event: DragEvent) => {
      const transfer = event.dataTransfer;
      if (!transfer) return;
      const dropped = transfer.getData("text/uri-list") || transfer.getData("text/plain");
      const postUrl = extractXPostUrl(dropped);
      if (!postUrl) return;
      event.preventDefault();
      setExternalXUrl(postUrl);
      setSection("downloads");
    };
    window.addEventListener("dragover", onDragOver);
    window.addEventListener("drop", onDrop);
    return () => {
      window.removeEventListener("dragover", onDragOver);
      window.removeEventListener("drop", onDrop);
    };
  }, []);

  useEffect(() => {
    if (section !== "home") return;
    let active = true;
    setHomeMediaLoading(true);
    void listMediaItems({
      favoritesOnly: true,
      sortBy: "modifiedAt",
      sortDirection: "desc",
      limit: 24,
    }).then((result) => {
      if (!active) return;
      setHomeFavoriteMedia(result.data);
      setHomeMediaLoading(false);
      if (result.error) setError((current) => current ?? result.error);
    });
    return () => { active = false; };
  }, [section, summary.favorites]);

  const openHomeFolder = useCallback((folder: FolderActivityRecord) => {
    rememberFolderNavigation(folder.navigationKey, {
      rootId: folder.rootId,
      path: folder.relativePath,
    });
    navigateToSection(folder.navigationKey === "images" ? "folders" : folder.navigationKey);
  }, [navigateToSection]);

  const removeHomeFolderFavorite = useCallback((folder: FolderActivityRecord) => {
    void setFolderFavorite({
      rootId: folder.rootId,
      relativePath: folder.relativePath,
      displayName: folder.displayName,
      rootName: folder.rootName,
      itemCount: folder.itemCount,
      navigationKey: folder.navigationKey,
    }, false).catch((caught: unknown) => {
      setError(caught instanceof Error ? caught.message : "お気に入りフォルダーを更新できませんでした。");
    });
  }, []);

  useEffect(() => {
    void refresh(false);
  }, [refresh]);

  async function addFolder() {
    const operation = startOperation({
      label: "フォルダーを追加",
      detail: "追加するフォルダーを選択しています",
      progress: null,
    });
    setError(undefined);
    setBusy(true);
    try {
      const picked = await pickLibraryRoot();
      if (picked.error) {
        setError(picked.error);
        operation.fail(picked.error);
        return;
      }
      if (!picked.data) {
        operation.cancel("フォルダーの追加をキャンセルしました");
        return;
      }

      operation.update({ detail: "フォルダーを登録しています" });
      const added = await addLibraryRoot(picked.data);
      if (!added.data || added.error) {
        const addError = added.error ?? "フォルダーを登録できませんでした。";
        setError(addError);
        operation.fail(addError);
        return;
      }

      operation.update({
        label: `${added.data.displayName}を追加`,
        detail: "メディアを初回スキャンしています",
      });
      const scanResult = await scanLibrary(added.data.id);
      const refreshError = await refresh(false);
      const finalError = scanResult.error ?? refreshError;
      if (finalError) {
        setError(finalError);
        operation.fail(finalError);
      } else {
        operation.succeed(
          `${scanResult.data.totalItems.toLocaleString("ja-JP")}件をカタログへ反映しました`,
        );
      }
      navigateToSection("gallery");
    } catch (caught) {
      const addError = operationErrorMessage(caught);
      setError(addError);
      operation.fail(addError);
    } finally {
      setBusy(false);
    }
  }

  async function scan(rootId?: string) {
    const root = rootId ? roots.find((item) => item.id === rootId) : undefined;
    const operation = startOperation({
      label: root ? `${root.displayName}を再スキャン` : "すべてのフォルダーを再スキャン",
      detail: "追加・変更されたメディアを確認しています",
      progress: null,
    });
    setError(undefined);
    setBusy(true);
    try {
      const result = await scanLibrary(rootId);
      const refreshError = await refresh(false);
      const finalError = result.error ?? refreshError;
      if (finalError) {
        setError(finalError);
        operation.fail(finalError);
      } else {
        operation.succeed(
          `${result.data.totalItems.toLocaleString("ja-JP")}件を確認しました`,
        );
      }
    } catch (caught) {
      const scanError = operationErrorMessage(caught);
      setError(scanError);
      operation.fail(scanError);
    } finally {
      setBusy(false);
    }
  }

  async function removeRoot(root: LibraryRoot) {
    if (!window.confirm(`「${root.displayName}」を登録解除しますか？ ファイル自体は削除されません。`)) return;
    const operation = startOperation({
      label: `${root.displayName}の登録を解除`,
      detail: "ライブラリ設定を更新しています",
      progress: null,
    });
    setError(undefined);
    setBusy(true);
    try {
      const result = await removeLibraryRoot(root.id);
      const refreshError = await refresh(false);
      const finalError =
        result.error ??
        (!result.data ? "フォルダーを登録解除できませんでした。" : undefined) ??
        refreshError;
      if (finalError) {
        setError(finalError);
        operation.fail(finalError);
      } else {
        operation.succeed("登録を解除しました。ファイルは削除されていません");
      }
    } catch (caught) {
      const removeError = operationErrorMessage(caught);
      setError(removeError);
      operation.fail(removeError);
    } finally {
      setBusy(false);
    }
  }

  function home() {
    return (
      <div className="dashboard functional-dashboard">
        {error && <div className="operation-message error"><Icon name="warning" />{error}</div>}
        {!nativeAvailable && !loading && (
          <div className="operation-message warning"><Icon name="info" />
            ブラウザーのプレビューではフォルダーを操作できません。インストールしたPixVaultアプリから開いてください。
          </div>
        )}
        <section className="hero functional-hero">
          <div>
            <p className="kicker">WINDOWS MEDIA LIBRARY</p>
            <h1>このPCのメディアを、<br />ひとつのライブラリに。</h1>
            <p className="hero-copy">
              フォルダーを登録すると、画像・GIF・動画・PDF・ZIPを安全にカタログ化します。削除はWindowsのごみ箱へ送られ、元のフォルダー構成は変更しません。
            </p>
            <div className="hero-actions">
              <button className="primary-button" type="button" onClick={() => void addFolder()} disabled={busy || !nativeAvailable}>
                <Icon name="folderPlus" />{busy ? "処理中…" : "フォルダーを登録"}
              </button>
              <button className="secondary-button" type="button" onClick={() => void scan()} disabled={busy || roots.length === 0}>
                <Icon name="refresh" />すべて再スキャン
              </button>
            </div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="art-card card-back"><span /></div>
            <div className="art-card card-front"><div className="art-sun" /><div className="art-mountain mountain-one" /><div className="art-mountain mountain-two" /></div>
          </div>
        </section>

        <HomeShelves
          favoriteMedia={homeFavoriteMedia}
          mediaLoading={homeMediaLoading}
          roots={roots}
          onOpenMedia={setHomeSelectedMediaId}
          onOpenFolder={openHomeFolder}
          onRemoveFolderFavorite={removeHomeFolderFavorite}
        />

        <section>
          <div className="section-heading"><div><p className="kicker">LIBRARY STATUS</p><h2>ライブラリの状態</h2></div></div>
          <div className="stats-grid">
            <button type="button" onClick={() => navigateToSection("gallery")}><Icon name="image" /><span>画像・GIF</span><strong>{summary.images + summary.gifs}</strong></button>
            <button type="button" onClick={() => navigateToSection("videos")}><Icon name="video" /><span>動画</span><strong>{summary.videos}</strong></button>
            <button type="button" onClick={() => navigateToSection("books")}><Icon name="book" /><span>ブック</span><strong>{summary.books}</strong></button>
            <button type="button" onClick={() => navigateToSection("favorites")}><Icon name="star" /><span>お気に入り</span><strong>{summary.favorites}</strong></button>
            <div><Icon name="hardDrive" /><span>使用容量</span><strong>{formatBytes(summary.storageBytes)}</strong></div>
            <div><Icon name="folder" /><span>登録フォルダー</span><strong>{summary.libraryRoots}</strong></div>
          </div>
        </section>

        <section className="root-panel">
          <div className="section-heading"><div><p className="kicker">REGISTERED FOLDERS</p><h2>登録フォルダー</h2></div></div>
          {loading ? <p className="muted-copy">読み込み中…</p> : roots.length === 0 ? (
            <div className="empty-panel"><Icon name="folder" /><p>まだフォルダーが登録されていません。</p></div>
          ) : (
            <div className="root-list">
              {roots.map((root) => <article key={root.id}><Icon name="folder" /><div><strong>{root.displayName}</strong><span>{root.path}</span><small>{root.mediaCount} 件のメディア</small></div><button type="button" onClick={() => void scan(root.id)} disabled={busy}>再スキャン</button></article>)}
            </div>
          )}
        </section>
        {homeSelectedMediaId && (
          <MediaViewer
            items={homeFavoriteMedia}
            currentId={homeSelectedMediaId}
            onClose={() => {
              setHomeSelectedMediaId(undefined);
              setHomeFavoriteMedia((current) => current.filter((item) => item.isFavorite));
            }}
            onItemPatch={(mediaId, patch) => {
              setHomeFavoriteMedia((current) => current.map((item) =>
                item.id === mediaId ? { ...item, ...patch } : item));
              void refreshSummary();
            }}
            onRemove={(mediaId) => {
              setHomeSelectedMediaId(undefined);
              setHomeFavoriteMedia((current) => current.filter((item) => item.id !== mediaId));
              void refreshSummary();
            }}
          />
        )}
      </div>
    );
  }

  function settings() {
    return (
      <div className="dashboard functional-dashboard">
        {error && <div className="operation-message error"><Icon name="warning" />{error}</div>}
        <section className="settings-panel">
          <div className="section-heading"><div><p className="kicker">LIBRARY SETTINGS</p><h2>登録フォルダーを管理</h2></div><button className="primary-button" type="button" onClick={() => void addFolder()} disabled={busy || !nativeAvailable}><Icon name="folderPlus" />追加</button></div>
          {roots.length === 0 ? <div className="empty-panel"><Icon name="folder" /><p>フォルダーを登録すると、ここで再スキャンや登録解除ができます。</p></div> : <div className="root-list settings-root-list">{roots.map((root) => <article key={root.id}><Icon name="folder" /><div><strong>{root.displayName}</strong><span>{root.path}</span><small>{root.mediaCount} 件のメディア</small></div><button type="button" onClick={() => void scan(root.id)} disabled={busy}>再スキャン</button><button className="danger-button" type="button" onClick={() => void removeRoot(root)} disabled={busy}>登録解除</button></article>)}</div>}
        </section>
        <section className="settings-panel">
          <div className="section-heading"><div><p className="kicker">X DOWNLOADER</p><h2>ダウンロード設定</h2></div></div>
          <XDownloadDirectorySetting />
        </section>
        <section className="settings-panel">
          <div className="section-heading">
            <div>
              <p className="kicker">BOOK VIEWER</p>
              <h2>ブック表示設定</h2>
            </div>
          </div>
          <BookViewerSettings />
        </section>
        <section className="settings-panel">
          <div className="section-heading">
            <div>
              <p className="kicker">VIDEO VIEWER</p>
              <h2>動画再生設定</h2>
            </div>
          </div>
          <VideoViewerSettings />
        </section>
        <section className="settings-panel">
          <div className="section-heading">
            <div>
              <p className="kicker">GALLERY</p>
              <h2>ギャラリー表示</h2>
            </div>
          </div>
          <GalleryDisplaySettings />
          <div className="section-heading search-grouping-settings-heading">
            <div>
              <p className="kicker">SEARCH &amp; GROUPING</p>
              <h2>検索履歴と類似画像</h2>
            </div>
          </div>
          <SearchAndGroupingSettings />
          <div className="section-heading gallery-media-visibility-heading">
            <div>
              <p className="kicker">MEDIA TYPES</p>
              <h2>ギャラリーの表示メディア</h2>
            </div>
          </div>
          <GalleryMediaSettings />
        </section>
        <section className="settings-panel">
          <div className="section-heading">
            <div>
              <p className="kicker">MEDIA VIEWER</p>
              <h2>情報とレコメンドの表示</h2>
            </div>
          </div>
          <div className="viewer-layout-setting">
            <span className="viewer-layout-setting-icon"><Icon name="sparkles" /></span>
            <span>
              <strong>ビュワーの情報表示</strong>
              <small>画像・動画・ブックのタグ、詳細情報、おすすめを表示する位置です。</small>
            </span>
            <SelectMenu
              value={viewerInfoLayout}
              options={[
                { value: "sidebar", label: "右サイドバー", description: "右端へスナップ。閉じたまま下部へドラッグできます" },
                { value: "bottomSheet", label: "レコメンドボトムシート", description: "初期非表示。自由移動し、右端でサイドバーへ変形します" },
              ]}
              ariaLabel="ビュワーの情報表示"
              disabled={savingViewerInfoLayout}
              onChange={(value) => void changeViewerInfoLayout(value)}
            />
          </div>
          <ViewerControlSettings />
        </section>
        <section className="settings-panel">
          <div className="section-heading">
            <div>
              <p className="kicker">QUICK TOUR</p>
              <h2>チュートリアル</h2>
            </div>
            <button
              className="secondary-button"
              type="button"
              onClick={() => window.dispatchEvent(new Event(firstRunTutorialOpenEvent))}
            >
              <Icon name="play" />もう一度見る
            </button>
          </div>
          <p className="muted-copy">
            フォルダー登録、ビュワー、AI分析、便利機能まで基本操作を6ステップで確認できます。
          </p>
        </section>
        <DataPortabilitySettings
          nativeAvailable={nativeAvailable}
          migrationFormatVersion={runtimeInfo?.migrationFormatVersion ?? 1}
          onDataChanged={() => void refresh()}
        />
      </div>
    );
  }

  function about() {
    return (
      <div className="dashboard functional-dashboard info-dashboard">
        <section className="settings-panel about-panel">
          <p className="kicker">ABOUT PIXVAULT</p>
          <h1>{runtimeInfo?.os === "linux" ? "PixVault for Linux" : "PixVault for Windows"}</h1>
          <p>画像・GIF・動画・ブックを、元のフォルダー構成を保ったまま管理するデスクトップメディアライブラリです。</p>
          <div className="application-facts">
            <span><small>バージョン</small><strong>{runtimeInfo?.appVersion ?? "…"}</strong></span>
            <span><small>カタログ</small><strong>SQLite v{runtimeInfo?.databaseSchemaVersion ?? "…"}</strong></span>
            <span><small>実行環境</small><strong>{runtimeInfo ? `${runtimeInfo.os} · ${runtimeInfo.arch}` : "確認中…"}</strong></span>
          </div>
          <p className="muted-copy">メディアの削除はOSのごみ箱を使用し、登録解除だけでは元ファイルを削除しません。</p>
        </section>
      </div>
    );
  }

  function changelog() {
    return (
      <div className="dashboard functional-dashboard info-dashboard">
        <section className="settings-panel changelog-panel">
          <p className="kicker">RELEASE NOTES</p>
          <h1>更新履歴</h1>
          <p className="muted-copy">各バージョンを選ぶと、その版で追加・改善された内容を確認できます。</p>
          <ReleaseHistory />
        </section>
      </div>
    );
  }

  function content() {
    if (section === "home") return home();
    if (section === "gallery") return <MediaCollection refreshVersion={catalogRefreshVersion} eyebrow="GALLERY" title="ギャラリー" description="画像・GIFを中心に、設定で動画・ブックもまとめて確認できます。" kinds={galleryMediaKinds} advancedGallerySearch tagNavigation={tagGalleryNavigation} emptyTitle="メディアはまだありません" emptyDescription="フォルダーを登録してスキャンしてください。" onAddFolder={() => void addFolder()} onDataChanged={refreshSummary} />;
    if (section === "folders") return <FolderMediaCollection key={`images:${catalogRefreshVersion}`} navigationKey="images" eyebrow="IMAGES" title="画像" description="画像とGIFだけを、元のフォルダー構成ごとに表示します。" kinds={IMAGE_MEDIA_KINDS} emptyTitle="画像フォルダーはまだありません" emptyDescription="画像またはGIFを含むフォルダーを登録してスキャンしてください。" onAddFolder={() => void addFolder()} onDataChanged={refreshSummary} />;
    if (section === "videos") return <FolderMediaCollection key={`videos:${catalogRefreshVersion}`} navigationKey="videos" eyebrow="VIDEOS" title="動画" description="動画をフォルダー単位で整理して表示します。" kinds={VIDEO_MEDIA_KINDS} emptyTitle="動画はまだありません" emptyDescription="フォルダーを登録してスキャンしてください。" onAddFolder={() => void addFolder()} onDataChanged={refreshSummary} />;
    if (section === "books") return <FolderMediaCollection key={`books:${catalogRefreshVersion}`} navigationKey="books" eyebrow="BOOKS" title="ブック" description="PDFとZIP/CBZをフォルダー単位で整理して表示します。" kinds={BOOK_MEDIA_KINDS} emptyTitle="ブックはまだありません" emptyDescription="フォルダーを登録してスキャンしてください。" onAddFolder={() => void addFolder()} onDataChanged={refreshSummary} />;
    if (section === "favorites") return <MediaCollection refreshVersion={catalogRefreshVersion} eyebrow="FAVORITES" title="お気に入り" description="星を付けたメディアを、形式で絞り込んで表示します。" favoritesOnly showFavoriteKindFilter emptyTitle="お気に入りはまだありません" emptyDescription="メディアカードの星ボタンで追加できます。" onAddFolder={() => void addFolder()} onDataChanged={refreshSummary} />;
    if (section === "sites") return <FavoriteSitesPage />;
    if (section === "creators") return <FavoriteCreatorsPage />;
    if (section === "references") return <DrawingReferencesPage />;
    if (section === "downloads") return (
      <XDownloaderPage
        initialUrl={externalXUrl}
        onInitialUrlConsumed={() => setExternalXUrl(undefined)}
      />
    );
    if (section === "about") return about();
    if (section === "changelog") return changelog();
    return settings();
  }

  return (
    <div className={`app-shell${sidebarMinimized ? " sidebar-minimized" : ""}`}>
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><span /><span /><span /></div>
          <div><strong>PixVault</strong><small>{runtimeInfo?.os === "linux" ? "for Linux" : "for Windows"}</small></div>
        </div>
        <button
          className="sidebar-collapse-button"
          type="button"
          aria-label={sidebarMinimized ? "サイドバーを展開" : "サイドバーを最小表示"}
          title={sidebarMinimized ? "サイドバーを展開" : "サイドバーを最小表示"}
          onClick={() => {
            const next = !sidebarMinimized;
            setSidebarMinimized(next);
            void setJsonPreference("sidebarMinimized", next);
          }}
        >
          <Icon name="chevronRight" />
        </button>
        <nav aria-label="メインナビゲーション">
          {navigationGroups.map((group, groupIndex) => (
            <div className="nav-group" key={group.label ?? `primary-${groupIndex}`}>
              {group.label && <span className="nav-section-label">{group.label}</span>}
              {group.items.map((item) => (
                <button className={section === item.id ? "nav-item active" : "nav-item"} key={item.id} onClick={() => navigateToSection(item.id)} type="button" title={item.label}>
                  <Icon name={item.icon} /><span>{item.label}</span>
                </button>
              ))}
            </div>
          ))}
          <div className="nav-version-label">
            <span>バージョン</span>
            <strong>{runtimeInfo?.appVersion ?? "…"}</strong>
          </div>
        </nav>
      </aside>
      <main className="main-panel"><header className="topbar"><div className="breadcrumbs"><span>PixVault</span><b>/</b><strong>{activeLabel}</strong></div><div className="topbar-actions"><NotificationCenter /><button className="icon-button" type="button" aria-label="再読み込み" onClick={() => void refresh()} disabled={loading || busy}><Icon name="refresh" /></button></div></header><Suspense fallback={<div className="empty-panel"><span className="spinner" /><p>読み込み中…</p></div>}>{content()}</Suspense></main>
      <OperationTray />
      {aiAnalysisPanelRequest && (
        <Suspense fallback={null}>
          <AIAnalysisModal
            key={aiAnalysisPanelRequest.requestId}
            open
            selectedItems={[]}
            initialRootId={aiAnalysisPanelRequest.rootId}
            initialFolderPath={aiAnalysisPanelRequest.folderPath}
            currentFolderOnly={aiAnalysisPanelRequest.currentFolderOnly}
            floating
            onClose={() => setAiAnalysisPanelRequest(undefined)}
          />
        </Suspense>
      )}
      <Suspense fallback={null}>
        <AiAnalysisMonitor hidden={Boolean(aiAnalysisPanelRequest)} />
        <FirstRunTutorial />
      </Suspense>
    </div>
  );
}

function formatBytes(value: number): string {
  if (!Number.isFinite(value) || value <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
  const size = value / 1024 ** index;
  return `${size >= 10 || index === 0 ? Math.round(size) : size.toFixed(1)} ${units[index]}`;
}

export default App;
