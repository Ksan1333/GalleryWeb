use std::{
    collections::{HashMap, HashSet, hash_map::DefaultHasher},
    hash::{Hash, Hasher},
    path::Path,
    time::{Duration, Instant, UNIX_EPOCH},
};

use serde::Serialize;
use serde_json::Value;
use tauri::{AppHandle, Emitter, Manager};
use walkdir::WalkDir;

use crate::{ai, background_activity, catalog, db::AppState, media_folders};

pub const LIBRARY_WATCH_EVENT: &str = "library-watch-updated";
const PENDING_ANALYSIS_KEY: &str = "watcher.pendingAnalysisIds";
const POLL_INTERVAL: Duration = Duration::from_secs(4);
const CHANGE_STABILITY_DELAY: Duration = Duration::from_millis(1_200);
const AUTO_ANALYSIS_BATCH: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct RootFingerprint {
    files: u64,
    bytes: u64,
    hash: u64,
}

#[derive(Debug, Clone)]
struct PendingRootChange {
    fingerprint: RootFingerprint,
    stable_since: Instant,
}

#[derive(Debug)]
struct ActiveAutoAnalysis {
    job_id: String,
    media_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct LibraryWatchEvent {
    root_id: String,
    inserted: u64,
    updated: u64,
    missing: u64,
    queued_for_analysis: usize,
}

pub fn start(app: AppHandle, database_path: std::path::PathBuf) {
    if let Err(error) = std::thread::Builder::new()
        .name("pixvault-folder-watcher".to_owned())
        .spawn(move || run(app, database_path))
    {
        eprintln!("Cannot start the registered-folder watcher: {error}");
    }
}

fn run(app: AppHandle, database_path: std::path::PathBuf) {
    let Ok(state) = AppState::open(&database_path) else {
        return;
    };
    let mut baselines = HashMap::<String, RootFingerprint>::new();
    let mut changes = HashMap::<String, PendingRootChange>::new();
    let mut pending_analysis = load_pending_analysis(&state);
    let mut active_auto_analysis: Option<ActiveAutoAnalysis> = None;
    let mut retry_auto_after = Instant::now();

    loop {
        background_activity::wait_until_quiet(
            Duration::from_millis(650),
            Duration::from_millis(100),
        );
        let preferences = preference_flags(&state);
        update_active_auto_analysis(
            &app,
            &state,
            &mut pending_analysis,
            &mut active_auto_analysis,
            &mut retry_auto_after,
        );

        if preferences.auto_analyze
            && active_auto_analysis.is_none()
            && !pending_analysis.is_empty()
            && Instant::now() >= retry_auto_after
        {
            start_pending_auto_analysis(
                &app,
                &pending_analysis,
                &mut active_auto_analysis,
                &mut retry_auto_after,
            );
        }

        if preferences.watch_folders {
            if let Ok(roots) = catalog::list_library_roots(&state) {
                let active_roots = roots
                    .iter()
                    .filter(|root| root.enabled)
                    .map(|root| root.id.clone())
                    .collect::<HashSet<_>>();
                baselines.retain(|root_id, _| active_roots.contains(root_id));
                changes.retain(|root_id, _| active_roots.contains(root_id));

                for root in roots.into_iter().filter(|root| root.enabled) {
                    let Ok(fingerprint) = root_fingerprint(Path::new(&root.path)) else {
                        // Unavailable removable/network roots must not be
                        // interpreted as deleting every catalogued file.
                        changes.remove(&root.id);
                        continue;
                    };
                    let Some(baseline) = baselines.get(&root.id).copied() else {
                        baselines.insert(root.id, fingerprint);
                        continue;
                    };
                    if fingerprint == baseline {
                        changes.remove(&root.id);
                        continue;
                    }
                    let now = Instant::now();
                    let pending =
                        changes
                            .entry(root.id.clone())
                            .or_insert_with(|| PendingRootChange {
                                fingerprint,
                                stable_since: now,
                            });
                    if pending.fingerprint != fingerprint {
                        pending.fingerprint = fingerprint;
                        pending.stable_since = now;
                        continue;
                    }
                    if now.duration_since(pending.stable_since) < CHANGE_STABILITY_DELAY {
                        continue;
                    }

                    let scan_started_at = catalog::now_millis();
                    match catalog::scan_library(&state, Some(&root.id)) {
                        Ok(report) => {
                            let new_ids = query_new_analyzable_ids(&state, scan_started_at);
                            if preferences.auto_analyze && !new_ids.is_empty() {
                                pending_analysis.extend(new_ids);
                                persist_pending_analysis(&state, &pending_analysis);
                            }
                            let _ = media_folders::refresh_folder_hierarchy_cache(
                                &state,
                                Some(&root.id),
                            );
                            crate::invalidate_media_presence_cache();
                            crate::schedule_media_maintenance(
                                app.clone(),
                                database_path.clone(),
                                128,
                                Duration::from_secs(2),
                            );
                            let _ = app.emit(
                                LIBRARY_WATCH_EVENT,
                                LibraryWatchEvent {
                                    root_id: root.id.clone(),
                                    inserted: report.inserted,
                                    updated: report.updated,
                                    missing: report.missing,
                                    queued_for_analysis: pending_analysis.len(),
                                },
                            );
                            if let Ok(current) = root_fingerprint(Path::new(&root.path)) {
                                baselines.insert(root.id.clone(), current);
                            }
                        }
                        Err(error) => eprintln!("Registered-folder rescan failed: {error}"),
                    }
                    changes.remove(&root.id);
                }
            }
        } else {
            changes.clear();
            baselines.clear();
        }

        std::thread::sleep(POLL_INTERVAL);
    }
}

#[derive(Debug, Clone, Copy)]
struct WatchPreferences {
    watch_folders: bool,
    auto_analyze: bool,
}

fn preference_flags(state: &AppState) -> WatchPreferences {
    let mut flags = WatchPreferences {
        watch_folders: true,
        auto_analyze: false,
    };
    if let Ok(entries) = catalog::get_preferences(state) {
        for entry in entries {
            match entry.key.as_str() {
                "watchFolders" => {
                    flags.watch_folders = entry.value.as_bool().unwrap_or(flags.watch_folders)
                }
                "autoAnalyze" => {
                    flags.auto_analyze = entry.value.as_bool().unwrap_or(flags.auto_analyze)
                }
                _ => {}
            }
        }
    }
    flags
}

fn root_fingerprint(root: &Path) -> Result<RootFingerprint, String> {
    let canonical = root
        .canonicalize()
        .map_err(|error| format!("Cannot resolve watched root {}: {error}", root.display()))?;
    if !canonical.is_dir() {
        return Err(format!(
            "Watched root is not a directory: {}",
            canonical.display()
        ));
    }
    let mut entries = Vec::new();
    for entry in WalkDir::new(&canonical).follow_links(false).into_iter() {
        let entry = entry.map_err(|error| format!("Cannot inspect watched root: {error}"))?;
        if !entry.file_type().is_file() || catalog::classify_media(entry.path()).is_none() {
            continue;
        }
        let metadata = entry
            .metadata()
            .map_err(|error| format!("Cannot read watched file metadata: {error}"))?;
        let relative = entry
            .path()
            .strip_prefix(&canonical)
            .map_err(|_| "A watched file escaped its registered root".to_owned())?
            .to_string_lossy()
            .replace('\\', "/");
        let modified = metadata
            .modified()
            .ok()
            .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
            .map(|duration| duration.as_millis())
            .unwrap_or_default();
        entries.push((relative, metadata.len(), modified));
    }
    entries.sort_unstable_by(|left, right| left.0.cmp(&right.0));
    let mut hasher = DefaultHasher::new();
    let mut bytes = 0_u64;
    for (path, size, modified) in &entries {
        path.hash(&mut hasher);
        size.hash(&mut hasher);
        modified.hash(&mut hasher);
        bytes = bytes.saturating_add(*size);
    }
    Ok(RootFingerprint {
        files: entries.len() as u64,
        bytes,
        hash: hasher.finish(),
    })
}

fn query_new_analyzable_ids(state: &AppState, scan_started_at: i64) -> Vec<String> {
    let Ok(connection) = state.database.lock() else {
        return Vec::new();
    };
    let Ok(mut statement) = connection.prepare(
        "SELECT m.id
         FROM media_items m
         LEFT JOIN media_metadata mm ON mm.media_id = m.id
         WHERE m.is_missing = 0
           AND m.media_kind IN ('image', 'gif')
           AND m.first_seen_at >= ?1
           AND COALESCE(mm.is_ai_analyzed, 0) = 0
         ORDER BY m.first_seen_at, m.id
         LIMIT 1000",
    ) else {
        return Vec::new();
    };
    statement
        .query_map([scan_started_at], |row| row.get::<_, String>(0))
        .ok()
        .into_iter()
        .flat_map(|rows| rows.filter_map(Result::ok))
        .collect()
}

fn load_pending_analysis(state: &AppState) -> HashSet<String> {
    catalog::get_preferences(state)
        .ok()
        .and_then(|entries| {
            entries
                .into_iter()
                .find(|entry| entry.key == PENDING_ANALYSIS_KEY)
        })
        .and_then(|entry| entry.value.as_array().cloned())
        .unwrap_or_default()
        .into_iter()
        .filter_map(|value| value.as_str().map(ToOwned::to_owned))
        .filter(|value| !value.is_empty() && value.len() <= 128)
        .take(10_000)
        .collect()
}

fn persist_pending_analysis(state: &AppState, pending: &HashSet<String>) {
    let mut media_ids = pending.iter().cloned().collect::<Vec<_>>();
    media_ids.sort_unstable();
    let _ = catalog::set_preference(
        state,
        PENDING_ANALYSIS_KEY,
        Value::Array(media_ids.into_iter().map(Value::String).collect()),
    );
}

fn start_pending_auto_analysis(
    app: &AppHandle,
    pending: &HashSet<String>,
    active: &mut Option<ActiveAutoAnalysis>,
    retry_after: &mut Instant,
) {
    let mut media_ids = pending
        .iter()
        .take(AUTO_ANALYSIS_BATCH)
        .cloned()
        .collect::<Vec<_>>();
    media_ids.sort_unstable();
    let catalog_state = app.state::<AppState>();
    let ai_state = app.state::<ai::AiRuntimeState>();
    match ai::start_ai_analysis(
        app.clone(),
        catalog_state,
        ai_state,
        Some(media_ids.clone()),
        None,
        Some("standard".to_owned()),
        Some(media_ids.len()),
    ) {
        Ok(job) => {
            *active = Some(ActiveAutoAnalysis {
                job_id: job.job_id,
                media_ids,
            });
        }
        Err(_) => *retry_after = Instant::now() + Duration::from_secs(20),
    }
}

fn update_active_auto_analysis(
    app: &AppHandle,
    state: &AppState,
    pending: &mut HashSet<String>,
    active: &mut Option<ActiveAutoAnalysis>,
    retry_after: &mut Instant,
) {
    let Some(job) = active.as_ref() else {
        return;
    };
    let Ok(progress) = ai::get_ai_analysis_status(app.state::<ai::AiRuntimeState>()) else {
        return;
    };
    if progress.job_id.as_deref() != Some(job.job_id.as_str()) {
        return;
    }
    match progress.phase.as_str() {
        "completed" => {
            for media_id in &job.media_ids {
                pending.remove(media_id);
            }
            persist_pending_analysis(state, pending);
            *active = None;
        }
        "failed" | "cancelled" => {
            *active = None;
            *retry_after = Instant::now() + Duration::from_secs(60);
        }
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use std::fs;

    use super::*;

    #[test]
    fn fingerprint_tracks_supported_media_but_ignores_other_files() {
        let directory = tempfile::tempdir().expect("watch fixture");
        let initial = root_fingerprint(directory.path()).expect("empty fingerprint");
        fs::write(directory.path().join("notes.txt"), b"ignored").expect("text fixture");
        assert_eq!(root_fingerprint(directory.path()).unwrap(), initial);

        fs::write(directory.path().join("image.png"), b"first").expect("image fixture");
        let added = root_fingerprint(directory.path()).expect("added fingerprint");
        assert_eq!(added.files, 1);
        assert_ne!(added, initial);

        fs::write(directory.path().join("image.png"), b"changed-media").expect("changed fixture");
        assert_ne!(root_fingerprint(directory.path()).unwrap(), added);
    }

    #[test]
    fn auto_analysis_queue_uses_the_persisted_analysis_flag() {
        let state = AppState::in_memory().expect("in-memory catalog");
        state
            .database
            .lock()
            .expect("database")
            .execute_batch(
                "INSERT INTO library_roots(id, path, display_name, enabled, created_at, updated_at)
                 VALUES ('root', 'C:\\fixture', 'fixture', 1, 1, 1);
                 INSERT INTO media_items(
                     id, root_id, relative_path, file_name, extension, media_kind,
                     mime_type, byte_size, modified_at, first_seen_at, last_seen_at, updated_at
                 ) VALUES
                     ('new', 'root', 'new.png', 'new.png', 'png', 'image', 'image/png', 1, 100, 100, 100, 100),
                     ('done', 'root', 'done.gif', 'done.gif', 'gif', 'gif', 'image/gif', 1, 100, 100, 100, 100);
                 INSERT INTO media_metadata(media_id, is_ai_analyzed, updated_at)
                 VALUES ('new', 0, 100), ('done', 1, 100);",
            )
            .expect("fixtures");

        assert_eq!(query_new_analyzable_ids(&state, 100), vec!["new"]);
    }
}
